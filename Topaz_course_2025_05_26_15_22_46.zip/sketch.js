function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let player;
let clouds = [];
let grassOffsets = [];
let numGrassBlades = 100;

function setup() {
  createCanvas(800, 600);
  player = new Player(width / 2, height - 100);

  // Criar nuvens em posições aleatórias no céu
  for (let i = 0; i < 5; i++) {
    clouds.push(new Cloud(random(width), random(50, 150)));
  }

  // Criar offsets para lâminas de grama para animar balançando
  for (let i = 0; i < numGrassBlades; i++) {
    grassOffsets.push(random(TWO_PI));
  }
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawSun();
  drawClouds();
  drawField();
  drawTree();
  player.update();
  player.display();
}

// Sol simples
function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(700, 100, 80, 80);
}

// Desenhar e atualizar nuvens
function drawClouds() {
  for (let cloud of clouds) {
    cloud.update();
    cloud.display();
  }
}

// Desenha o campo com grama animada
function drawField() {
  // Grama base
  fill(34, 139, 34);
  noStroke();
  rect(0, height / 2, width, height / 2);

  // Desenhar lâminas de grama animadas
  stroke(0, 100, 0);
  strokeWeight(2);
  for (let i = 0; i < numGrassBlades; i++) {
    let x = i * (width / numGrassBlades);
    let baseY = height / 2 + 20 + sin(frameCount * 0.05 + grassOffsets[i]) * 5;
    line(x, height / 2 + 100, x, baseY);
  }
  noStroke();
}

// Desenho de uma árvore com folhas que balançam
function drawTree() {
  // Tronco
  fill(139, 69, 19);
  rect(150, height / 2 + 50, 30, 100);

  // Folhas animadas
  fill(34, 139, 34);
  let sway = sin(frameCount * 0.1) * 10;
  ellipse(165 + sway, height / 2 + 30, 80, 80);
  ellipse(130 + sway, height / 2 + 50, 60, 60);
  ellipse(200 + sway, height / 2 + 50, 60, 60);
}

// Classe nuvem
class Cloud {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = random(0.3, 1);
  }

  update() {
    this.x += this.speed;
    if (this.x > width + 50) {
      this.x = -50;
      this.y = random(50, 150);
      this.speed = random(0.3, 1);
    }
  }

  display() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, 50, 50);
    ellipse(this.x + 30, this.y + 10, 50, 50);
    ellipse(this.x - 30, this.y + 10, 50, 50);
  }
}

// Classe jogador
class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 40;
    this.speed = 5;
    this.color = color(255, 0, 0);
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Limitar posição dentro do campo
    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, height / 2, height - this.size);
  }

  display() {
    fill(this.color);
    rect(this.x, this.y, this.size, this.size);
  }
}
